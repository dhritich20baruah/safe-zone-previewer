import SafeZoneCanvas from "@/components/SafeZonecanvas";

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center p-6 md:p-12">
      {/* ── Hero / H1 Section ── */}
      <header className="max-w-4xl text-center mb-8">
        <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl mb-4">
          Free{" "}
          <span className="text-blue-600">Safe Zone Preview</span>{" "}
          Tool for TikTok, Instagram &amp; YouTube
        </h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Upload your design and instantly preview the{" "}
          <strong>TikTok safe zone</strong>,{" "}
          <strong>Instagram Reels safe zone</strong>,{" "}
          <strong>IG Story safe zone</strong>, and{" "}
          <strong>YouTube Shorts safe zone</strong> — all in one place. No
          login, no watermark, completely free.
        </p>
      </header>

      {/* ── Interactive Safe Zone Previewer ── */}
      <section
        aria-label="Safe zone preview canvas"
        className="w-full max-w-6xl bg-white rounded-2xl shadow-xl border border-slate-100 p-6"
      >
        <SafeZoneCanvas />
      </section>

      {/* ── Platform Guide Section (keyword-rich, scannable) ── */}
      <section className="max-w-4xl w-full mt-14 grid grid-cols-1 sm:grid-cols-2 gap-6">
        <article className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
          <h2 className="text-lg font-bold text-slate-800 mb-2">
            TikTok Safe Zone
          </h2>
          <p className="text-sm text-slate-600">
            TikTok overlays your video with a right-side action bar (Like,
            Comment, Share) and bottom caption text. Our{" "}
            <strong>TikTok safe zone template</strong> preview shows exactly
            which pixels are hidden so your key content stays visible.
          </p>
        </article>

        <article className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
          <h2 className="text-lg font-bold text-slate-800 mb-2">
            Instagram Reels &amp; Story Safe Zone
          </h2>
          <p className="text-sm text-slate-600">
            Instagram blocks the right side with reaction icons and the bottom
            with profile info. Preview the{" "}
            <strong>IG Reel safe zone</strong> and{" "}
            <strong>Instagram Story safe zone</strong> before you post to make
            sure no critical text is cut off.
          </p>
        </article>

        <article className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
          <h2 className="text-lg font-bold text-slate-800 mb-2">
            YouTube Shorts Safe Zone
          </h2>
          <p className="text-sm text-slate-600">
            YouTube Shorts overlays a timestamp pill in the bottom-right corner
            of thumbnails. Use this tool as a{" "}
            <strong>YouTube Shorts safe zone</strong> checker to keep your
            title text unobscured.
          </p>
        </article>

        <article className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
          <h2 className="text-lg font-bold text-slate-800 mb-2">
            Create a Transparent Overlay Safe Zone Marking
          </h2>
          <p className="text-sm text-slate-600">
            Switch to <em>Safe-Zone Grid Only</em> mode to see a clean dashed
            boundary overlay — perfect for exporting and layering as a{" "}
            <strong>transparent safe zone marking</strong> in Canva, Figma,
            or Photoshop.
          </p>
        </article>
      </section>

      {/* ── How to Use (FAQ / instructional content for SEO) ── */}
      <section className="max-w-4xl w-full mt-10 bg-slate-50 rounded-xl p-6 border border-slate-100">
        <h2 className="text-xl font-bold text-slate-800 mb-4">
          How to Use the Safe Zone Preview Tool
        </h2>
        <ol className="list-decimal list-inside space-y-2 text-sm text-slate-600">
          <li>
            <strong>Select a platform</strong> — choose TikTok, Instagram
            Reels, or YouTube Thumbnail from the sidebar.
          </li>
          <li>
            <strong>Upload your design</strong> — drag &amp; drop or click to
            upload any PNG, JPG, or WebP file.
          </li>
          <li>
            <strong>Check the safe zone</strong> — the canvas instantly renders
            a realistic UI overlay so you can see hidden areas.
          </li>
          <li>
            <strong>Toggle grid mode</strong> — enable <em>Safe-Zone Grid
            Only</em> to display just the boundary lines for use as a template
            guide.
          </li>
        </ol>
      </section>

      {/* ── FAQ Schema-Ready Section ── */}
      <section className="max-w-4xl w-full mt-10">
        <h2 className="text-xl font-bold text-slate-800 mb-4">
          Frequently Asked Questions
        </h2>
        <div className="space-y-4">
          <details className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
            <summary className="font-semibold text-slate-700 cursor-pointer">
              What is a safe zone in TikTok or Instagram?
            </summary>
            <p className="mt-2 text-sm text-slate-600">
              A safe zone is the area of your video frame that remains visible
              after the platform&apos;s native UI elements (action buttons,
              captions, navigation tabs) are rendered on top. Keeping important
              text and visuals inside the safe zone ensures nothing is obscured
              for viewers.
            </p>
          </details>
          <details className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
            <summary className="font-semibold text-slate-700 cursor-pointer">
              Is this safe zone preview tool free to use?
            </summary>
            <p className="mt-2 text-sm text-slate-600">
              Yes — completely free, no account required. Your image is
              processed entirely in your browser and is never uploaded to a
              server.
            </p>
          </details>
          <details className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
            <summary className="font-semibold text-slate-700 cursor-pointer">
              Which platforms does the safe zone checker support?
            </summary>
            <p className="mt-2 text-sm text-slate-600">
              Currently supported: <strong>TikTok safe zone</strong> (9:16),{" "}
              <strong>Instagram Reels / IG Reel safe zone</strong> (9:16), and{" "}
              <strong>YouTube Thumbnail / Shorts safe zone</strong> (16:9).
              Instagram Story safe zone dimensions match the Reels 9:16 format.
            </p>
          </details>
          <details className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
            <summary className="font-semibold text-slate-700 cursor-pointer">
              Can I use this to create an Instagram safe zone template?
            </summary>
            <p className="mt-2 text-sm text-slate-600">
              Yes. Enable <em>Safe-Zone Grid Only</em> mode and take a
              screenshot of the dashed boundary lines. You can then import
              those lines as a transparent overlay into Canva, Adobe Express,
              or Figma to create a reusable{" "}
              <strong>Instagram safe zone template</strong> or{" "}
              <strong>TikTok safe zone template</strong>.
            </p>
          </details>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="max-w-4xl w-full mt-16 text-slate-400 text-xs border-t border-slate-200 pt-6 text-center">
        <p>
          Safe Zone Preview supports standard content dimensions: YouTube
          Thumbnails (1280×720, 16:9), TikTok Safe Zone (1080×1920, 9:16),
          Instagram Reels Safe Zone (1080×1920, 9:16), and IG Story Safe Zone
          (1080×1920, 9:16).
        </p>
        <p className="mt-2">
          Built for creators who want to design with confidence — no guessing,
          no cropped text.
        </p>
      </footer>
    </main>
  );
}
